"""Environment-facing adapter for a PyTorch Local Student."""

from __future__ import annotations

import numpy as np
import torch
from numpy.typing import NDArray

from .student_policy import (
    GeographicResidualStudentPolicy,
    LocalStudentPolicy,
    RiskAwareGeographicResidualStudentPolicy,
)
from .tensor_observation import observation_to_tensors


class StudentPolicyAdapter:
    """Expose deterministic or sampled actions through the baseline API."""

    def __init__(
        self,
        model: LocalStudentPolicy,
        *,
        device: torch.device | str = "cpu",
        deterministic: bool = True,
        force_forward_if_available: bool = False,
    ) -> None:
        self.model = model.to(device)
        self.device = torch.device(device)
        self.deterministic = deterministic
        self.force_forward_if_available = force_forward_if_available
        self.generator = torch.Generator(device=self.device)

    def reset(self, seed: int | None = None) -> None:
        self.generator.manual_seed(0 if seed is None else seed)

    def observation_bytes(
        self, observation: dict[str, NDArray[np.generic]]
    ) -> int:
        keys = {
            "self_features",
            "neighbor_features",
            "edge_features",
            "packet_features",
            "action_mask",
        }
        if isinstance(self.model, GeographicResidualStudentPolicy):
            keys.add("candidate_forwardability")
        if isinstance(
            self.model, RiskAwareGeographicResidualStudentPolicy
        ):
            keys.add("candidate_risk_features")
        return sum(
            int(observation[key].nbytes)
            for key in keys
            if key in observation
        )

    @torch.inference_mode()
    def act(self, observation: dict[str, NDArray[np.generic]]) -> int:
        tensors = observation_to_tensors(observation, device=self.device)
        probabilities = self.model(tensors).probabilities
        if self.deterministic:
            action = int(torch.argmax(probabilities).item())
            if (
                self.force_forward_if_available
                and action == self.model.drop_action
            ):
                candidate_mask = tensors["action_mask"][
                    : self.model.max_nodes
                ].to(torch.bool)
                if torch.any(candidate_mask):
                    candidate_probabilities = probabilities[
                        : self.model.max_nodes
                    ].masked_fill(~candidate_mask, -1.0)
                    action = int(
                        torch.argmax(candidate_probabilities).item()
                    )
            return action
        action = torch.multinomial(
            probabilities,
            num_samples=1,
            generator=self.generator,
        )
        return int(action.item())
