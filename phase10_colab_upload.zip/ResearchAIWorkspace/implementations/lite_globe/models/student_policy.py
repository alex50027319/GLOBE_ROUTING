"""Permutation-equivariant 1-hop Local Student policy."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence

import torch
from torch import Tensor, nn

from ..env.observation import (
    EDGE_FEATURES,
    NEIGHBOR_FEATURES,
    PACKET_FEATURES,
    SELF_FEATURES,
)
from .masking import masked_logits, masked_softmax


@dataclass(frozen=True)
class StudentPolicyOutput:
    """Masked policy tensors with a final explicit DROP action."""

    logits: Tensor
    masked_logits: Tensor
    probabilities: Tensor


class LocalStudentPolicy(nn.Module):
    """Score each 1-hop neighbor with shared MLPs and mean context pooling."""

    def __init__(self, max_nodes: int, hidden_dim: int = 64) -> None:
        super().__init__()
        if max_nodes < 2:
            raise ValueError("max_nodes must be at least 2")
        if hidden_dim not in {32, 64}:
            raise ValueError("hidden_dim must be 32 or 64")
        self.max_nodes = max_nodes
        self.drop_action = max_nodes
        self.hidden_dim = hidden_dim

        shared_dim = SELF_FEATURES + PACKET_FEATURES
        candidate_dim = shared_dim + NEIGHBOR_FEATURES + EDGE_FEATURES
        self.neighbor_encoder = nn.Sequential(
            nn.Linear(candidate_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
        )
        self.candidate_scorer = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
        )
        self.drop_scorer = nn.Sequential(
            nn.Linear(shared_dim + hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
        )

    def forward(
        self, observation: Mapping[str, Tensor]
    ) -> StudentPolicyOutput:
        """Produce masked probabilities for a single or batched observation."""

        tensors, unbatched = self._validate_and_batch(observation)
        self_features = tensors["self_features"]
        neighbors = tensors["neighbor_features"]
        edges = tensors["edge_features"]
        packet = tensors["packet_features"]
        action_mask = tensors["action_mask"]
        candidate_mask = action_mask[:, : self.max_nodes]

        shared = torch.cat((self_features, packet), dim=-1)
        expanded_shared = shared.unsqueeze(1).expand(-1, self.max_nodes, -1)
        candidate_input = torch.cat(
            (expanded_shared, neighbors, edges), dim=-1
        )
        encoded = self.neighbor_encoder(candidate_input)

        valid = candidate_mask.unsqueeze(-1).to(dtype=encoded.dtype)
        pooled = (encoded * valid).sum(dim=1)
        counts = valid.sum(dim=1).clamp_min(1.0)
        context = pooled / counts

        expanded_context = context.unsqueeze(1).expand(-1, self.max_nodes, -1)
        candidate_logits = self.candidate_scorer(
            torch.cat((encoded, expanded_context), dim=-1)
        ).squeeze(-1)
        drop_logit = self.drop_scorer(
            torch.cat((shared, context), dim=-1)
        )
        logits = torch.cat((candidate_logits, drop_logit), dim=-1)
        valid_logits = masked_logits(logits, action_mask)
        probabilities = masked_softmax(logits, action_mask)

        if unbatched:
            logits = logits.squeeze(0)
            valid_logits = valid_logits.squeeze(0)
            probabilities = probabilities.squeeze(0)
        return StudentPolicyOutput(logits, valid_logits, probabilities)

    def _validate_and_batch(
        self, observation: Mapping[str, Tensor]
    ) -> tuple[dict[str, Tensor], bool]:
        required = {
            "self_features",
            "neighbor_features",
            "edge_features",
            "packet_features",
            "action_mask",
        }
        missing = required.difference(observation)
        if missing:
            raise ValueError(f"observation is missing keys: {sorted(missing)}")

        self_features = observation["self_features"]
        unbatched = self_features.ndim == 1
        expected = {
            "self_features": (SELF_FEATURES,),
            "neighbor_features": (self.max_nodes, NEIGHBOR_FEATURES),
            "edge_features": (self.max_nodes, EDGE_FEATURES),
            "packet_features": (PACKET_FEATURES,),
            "action_mask": (self.max_nodes + 1,),
        }
        tensors: dict[str, Tensor] = {}
        batch_size: int | None = None
        for key, trailing_shape in expected.items():
            tensor = observation[key]
            expected_rank = len(trailing_shape) if unbatched else len(trailing_shape) + 1
            if tensor.ndim != expected_rank:
                raise ValueError(
                    f"{key} rank is {tensor.ndim}, expected {expected_rank}"
                )
            if tuple(tensor.shape[-len(trailing_shape) :]) != trailing_shape:
                raise ValueError(
                    f"{key} trailing shape is {tuple(tensor.shape)}, "
                    f"expected {trailing_shape}"
                )
            if unbatched:
                tensor = tensor.unsqueeze(0)
            elif batch_size is None:
                batch_size = tensor.shape[0]
            elif tensor.shape[0] != batch_size:
                raise ValueError("observation batch dimensions do not match")
            tensors[key] = tensor

        if tensors["action_mask"].dtype != torch.bool:
            tensors["action_mask"] = tensors["action_mask"].to(torch.bool)
        for key in required - {"action_mask"}:
            if not torch.is_floating_point(tensors[key]):
                tensors[key] = tensors[key].to(torch.float32)
            if not torch.all(torch.isfinite(tensors[key])):
                raise ValueError(f"{key} contains non-finite values")
        return tensors, unbatched


class GeographicResidualStudentPolicy(LocalStudentPolicy):
    """Learn residual routing corrections on top of geographic progress."""

    def __init__(
        self,
        max_nodes: int,
        hidden_dim: int = 64,
        *,
        initial_prior_strength: float = 8.0,
        initial_forwardability_strength: float = 0.05,
    ) -> None:
        if initial_prior_strength <= 0:
            raise ValueError("initial_prior_strength must be positive")
        if initial_forwardability_strength <= 0:
            raise ValueError(
                "initial_forwardability_strength must be positive"
            )
        super().__init__(max_nodes=max_nodes, hidden_dim=hidden_dim)
        self.log_prior_strength = nn.Parameter(
            torch.log(torch.expm1(torch.tensor(initial_prior_strength)))
        )
        self.register_buffer("residual_weight", torch.tensor(1.0))
        self.log_forwardability_strength = nn.Parameter(
            torch.log(
                torch.expm1(
                    torch.full(
                        (2,),
                        initial_forwardability_strength,
                    )
                )
            )
        )
        nn.init.zeros_(self.candidate_scorer[-1].weight)
        nn.init.zeros_(self.candidate_scorer[-1].bias)
        nn.init.zeros_(self.drop_scorer[-1].weight)
        nn.init.constant_(self.drop_scorer[-1].bias, -4.0)

    def forward(
        self, observation: Mapping[str, Tensor]
    ) -> StudentPolicyOutput:
        """Add a learnable GPSR-equivalent prior to learned candidate logits."""

        base = super().forward(observation)
        unbatched = observation["self_features"].ndim == 1
        neighbors = observation["neighbor_features"]
        packet = observation["packet_features"]
        action_mask = observation["action_mask"]
        if unbatched:
            neighbors = neighbors.unsqueeze(0)
            packet = packet.unsqueeze(0)
            action_mask = action_mask.unsqueeze(0)
            logits = base.logits.unsqueeze(0)
        else:
            logits = base.logits

        destination_delta = packet[:, :2].unsqueeze(1)
        neighbor_delta = neighbors[:, :, :2]
        current_distance = torch.linalg.vector_norm(
            destination_delta, dim=-1
        )
        next_distance = torch.linalg.vector_norm(
            destination_delta - neighbor_delta, dim=-1
        )
        geographic_progress = current_distance - next_distance
        strength = torch.nn.functional.softplus(self.log_prior_strength)
        forwardability = observation.get("candidate_forwardability")
        if forwardability is None:
            forwardability_bonus = torch.zeros_like(next_distance)
        else:
            if unbatched:
                forwardability = forwardability.unsqueeze(0)
            forwardability = forwardability.to(
                device=next_distance.device,
                dtype=next_distance.dtype,
            )
            forwardability_strength = torch.nn.functional.softplus(
                self.log_forwardability_strength
            )
            forwardability_bonus = torch.sum(
                forwardability * forwardability_strength,
                dim=-1,
            )
        candidate_logits = (
            self.residual_weight
            * (
                logits[:, : self.max_nodes]
                + forwardability_bonus
            )
            + strength * geographic_progress
        )
        drop_logits = (
            -20.0
            + self.residual_weight
            * (logits[:, self.max_nodes :] + 20.0)
        )
        combined = torch.cat(
            (candidate_logits, drop_logits), dim=-1
        )
        valid_logits = masked_logits(combined, action_mask)
        probabilities = masked_softmax(combined, action_mask)
        if unbatched:
            combined = combined.squeeze(0)
            valid_logits = valid_logits.squeeze(0)
            probabilities = probabilities.squeeze(0)
        return StudentPolicyOutput(combined, valid_logits, probabilities)

    def set_residual_weight(self, weight: float) -> None:
        """Set the validated interpolation between GPSR and learned residual."""

        if not 0.0 <= weight <= 1.0:
            raise ValueError("residual weight must be in [0, 1]")
        self.residual_weight.fill_(weight)


class RiskAwareGeographicResidualStudentPolicy(
    GeographicResidualStudentPolicy
):
    """Add a small stability, energy, and queue prior to Phase 8."""

    def __init__(
        self,
        max_nodes: int,
        hidden_dim: int = 64,
        *,
        initial_prior_strength: float = 8.0,
        initial_forwardability_strength: float = 0.05,
        initial_risk_strength: float | Sequence[float] = 0.05,
    ) -> None:
        if isinstance(initial_risk_strength, (int, float)):
            risk_strengths = torch.full(
                (4,), float(initial_risk_strength)
            )
        else:
            if len(initial_risk_strength) != 4:
                raise ValueError(
                    "initial_risk_strength must contain four values"
                )
            risk_strengths = torch.tensor(
                list(initial_risk_strength), dtype=torch.float32
            )
        if torch.any(risk_strengths <= 0):
            raise ValueError("initial_risk_strength must be positive")
        super().__init__(
            max_nodes=max_nodes,
            hidden_dim=hidden_dim,
            initial_prior_strength=initial_prior_strength,
            initial_forwardability_strength=(
                initial_forwardability_strength
            ),
        )
        self.log_risk_strength = nn.Parameter(
            torch.log(
                torch.expm1(
                    risk_strengths
                )
            )
        )
        self.register_buffer("risk_weight", torch.tensor(1.0))

    def forward(
        self, observation: Mapping[str, Tensor]
    ) -> StudentPolicyOutput:
        """Add positive deployable quality features to Phase 8 logits."""

        base = super().forward(observation)
        risk = observation.get("candidate_risk_features")
        if risk is None:
            return base
        unbatched = observation["self_features"].ndim == 1
        action_mask = observation["action_mask"]
        logits = base.logits
        if unbatched:
            risk = risk.unsqueeze(0)
            action_mask = action_mask.unsqueeze(0)
            logits = logits.unsqueeze(0)
        risk = risk.to(device=logits.device, dtype=logits.dtype)
        strengths = torch.nn.functional.softplus(
            self.log_risk_strength
        )
        bonus = torch.sum(risk * strengths, dim=-1)
        candidate_logits = (
            logits[:, : self.max_nodes]
            + self.risk_weight * bonus
        )
        combined = torch.cat(
            (candidate_logits, logits[:, self.max_nodes :]),
            dim=-1,
        )
        valid_logits = masked_logits(combined, action_mask)
        probabilities = masked_softmax(combined, action_mask)
        if unbatched:
            combined = combined.squeeze(0)
            valid_logits = valid_logits.squeeze(0)
            probabilities = probabilities.squeeze(0)
        return StudentPolicyOutput(
            combined,
            valid_logits,
            probabilities,
        )

    def set_risk_weight(self, weight: float) -> None:
        """Set the calibrated contribution of predictive risk features."""

        if not 0.0 <= weight <= 1.0:
            raise ValueError("risk weight must be in [0, 1]")
        self.risk_weight.fill_(weight)
